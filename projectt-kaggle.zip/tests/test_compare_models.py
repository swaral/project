import pytest

from scripts.compare_models import compare_model_records


def _record(
    model,
    session_id,
    *,
    baseline_rank,
    rwra_rank,
    prefix_length=4,
    member_successes=None,
):
    successes = member_successes or [True, True, True, True]
    member_trials = [
        {
            "parse_success": success,
            "target_rank": baseline_rank if index == 0 and success else (1 if success else None),
        }
        for index, success in enumerate(successes)
    ]
    return {
        "session_id": session_id,
        "client_config": {"model": model},
        "prefix_item_ids": list(range(prefix_length)),
        "candidate_item_ids": [10, 20, 30, 40],
        "target_item_id": 40,
        "member_trials": member_trials,
        "failure_reason": None if all(successes) and rwra_rank is not None else "member failure",
        "reliability_weighted": (
            {"target_rank": rwra_rank} if rwra_rank is not None else None
        ),
        "drift": {"mean_kendall_tau": 0.5},
    }


def test_sessions_are_matched_by_id_and_unmatched_rows_are_reported():
    records_3b = [
        _record("qwen2.5:3b-instruct", "shared", baseline_rank=4, rwra_rank=2),
        _record("qwen2.5:3b-instruct", "only-3b", baseline_rank=3, rwra_rank=1),
    ]
    records_7b = [
        _record("qwen2.5:7b-instruct", "shared", baseline_rank=2, rwra_rank=1),
        _record("qwen2.5:7b-instruct", "only-7b", baseline_rank=1, rwra_rank=1),
    ]

    summary = compare_model_records(records_3b, records_7b, n_boot=100, seed=0)

    alignment = summary["session_alignment"]
    assert alignment["matched_sessions"] == 1
    assert alignment["only_in_3b"] == 1
    assert alignment["only_in_7b"] == 1
    assert alignment["complete_success_sessions"] == 1
    assert summary["overall"]["comparisons"]["rwra_gain_reciprocal_rank_3b_vs_7b"]["n_pairs"] == 1


def test_sessions_with_a_failure_in_either_model_are_excluded_from_quality_pairs():
    records_3b = [
        _record("qwen2.5:3b-instruct", "ok", baseline_rank=4, rwra_rank=1),
        _record(
            "qwen2.5:3b-instruct",
            "failed",
            baseline_rank=5,
            rwra_rank=None,
            member_successes=[True, False, True, True],
        ),
    ]
    records_7b = [
        _record("qwen2.5:7b-instruct", "ok", baseline_rank=2, rwra_rank=1),
        _record("qwen2.5:7b-instruct", "failed", baseline_rank=2, rwra_rank=1),
    ]

    summary = compare_model_records(records_3b, records_7b, n_boot=100, seed=0)

    assert summary["session_alignment"]["matched_sessions"] == 2
    assert summary["session_alignment"]["complete_success_sessions"] == 1
    assert (
        summary["overall"]["comparisons"]["rwra_gain_reciprocal_rank_3b_vs_7b"][
            "n_pairs"
        ]
        == 1
    )
    # Failure-rate analysis retains that failed session instead of hiding it.
    assert summary["overall"]["comparisons"]["broken_answer_rate_3b_vs_7b"]["n_pairs"] == 2
    assert summary["overall"]["broken_answers"]["3b"]["broken_answers"] == 1


def test_paired_rwra_gain_difference_is_correct_on_a_small_example():
    records_3b = [
        _record("qwen2.5:3b-instruct", "u1", baseline_rank=4, rwra_rank=1),
        _record("qwen2.5:3b-instruct", "u2", baseline_rank=10, rwra_rank=2),
    ]
    records_7b = [
        _record("qwen2.5:7b-instruct", "u1", baseline_rank=2, rwra_rank=1),
        _record("qwen2.5:7b-instruct", "u2", baseline_rank=5, rwra_rank=4),
    ]

    summary = compare_model_records(records_3b, records_7b, n_boot=500, seed=0)

    gain_comparison = summary["overall"]["comparisons"][
        "rwra_gain_reciprocal_rank_3b_vs_7b"
    ]
    assert gain_comparison["n_pairs"] == 2
    assert gain_comparison["mean_3b"] == pytest.approx(0.575)
    assert gain_comparison["mean_7b"] == pytest.approx(0.275)
    assert gain_comparison["mean_difference_3b_minus_7b"] == pytest.approx(0.3)
    assert gain_comparison["bootstrap_ci"]["mean_difference"] == pytest.approx(0.3)
    assert gain_comparison["wilcoxon"]["n_pairs"] == 2
